torchvision.utils
=================

.. currentmodule:: torchvision.utils

.. autofunction:: make_grid

.. autofunction:: save_image

.. autofunction:: draw_bounding_boxes

.. autofunction:: draw_segmentation_masks
